
import React, { useState } from 'react';
import axios from 'axios';

const App = () => {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!input) return;
    const newMessages = [...messages, { role: "user", content: input }];
    setMessages(newMessages);
    setLoading(true);
    setInput('');
    try {
      const res = await axios.post(import.meta.env.VITE_API_BASE_URL + "/chat", {
        messages: newMessages,
      });
      const aiMessage = { role: "assistant", content: res.data.response };
      setMessages([...newMessages, aiMessage]);
    } catch (err) {
      alert("API Error");
    }
    setLoading(false);
  };

  return (
    <div style={{ maxWidth: 600, margin: "auto", padding: 20 }}>
      <h1>GPT 챗봇</h1>
      <div style={{ marginBottom: 20 }}>
        {messages.map((m, i) => (
          <div key={i}><b>{m.role}:</b> {m.content}</div>
        ))}
      </div>
      <input
        value={input}
        onChange={e => setInput(e.target.value)}
        placeholder="질문을 입력하세요"
        style={{ width: "80%" }}
      />
      <button onClick={sendMessage} disabled={loading}>
        {loading ? "전송 중..." : "전송"}
      </button>
    </div>
  );
};

export default App;
